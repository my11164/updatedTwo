<?php include('server.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin Registeration Form</title>
	<link rel="stylesheet" type="text/css" href="resources/style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body style="background-color: aliceblue;">
	<header class="headera1">
		<nav class="navbar navbar-expand-sm  justify-content-center nav1">
<a class="navbar-brand navbrand" href="index.php">
	<img src="resources/images/logo2.png" alt="website logo" height="50px;" width="">
</a>
  <!-- Links -->

 
  <ul class="nav navbar-nav navbar-right">
      
      <li class="nav-item navitem"><a href="adminLogin.php"><button class="btn btn1">Log In</button></a></li>
    </ul>

</nav>
	<div class="container" style="margin-top: 20px;">
		<div class="container1 form-a">
			<h3 class="h3-1">Admin Registeration Form</h3>
			<div class="row">
				<div class="col-sm-2"></div>
				<div class="col-sm-8 ">
					<div class="container">
  
				 <form action="server.php" method="post">
				    <div class="form-group">
				      <label for="name">User Name: <span style="color: red;">&#42;</span></label>
				      <input type="text" class="form-control"  placeholder="Enter your Name" name="adminusername" required="">
				    </div>
				     <div class="
				     form-group">
				      <label for="email">Email: <span style="color: red;">&#42;</span></label>
				      <input type="email" class="form-control"  placeholder="Enter email" name="adminemail" required="">
				    </div>
				   
				  	<div class="form-group">
				      <label for="pwd">Password: <span style="color: red;">&#42;</span></label>
				      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="adminpassword" required="">
				    </div>
				   
				    <button type="submit" class="btn btn1" name="admin_register">Submit</button>

				 </form>
				 
				</div>
				</div>
			</div>
			
		</div>
	</div>

</body>
</html>
