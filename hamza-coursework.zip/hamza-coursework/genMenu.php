<?php include('server.php'); 

?>

<!DOCTYPE html>
<html>
<head>
	<title>Menu</title>
	<link rel="stylesheet" type="text/css" href="resources/style.css">
	<link rel="stylesheet" href="resources/bootstrap-4/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
	<nav class="navbar navbar-expand-sm  justify-content-center nav1">
<a class="navbar-brand navbrand" href="index.php">
  <img src="resources/images/mainLogo.png" alt="website logo" height="90px;" width="">
</a>
  <!-- Links -->

  <ul class="navbar-nav ">
    <li class="nav-item navitem">
      <a class="nav-link nav_a" href="#">Home</a>
    </li>
  </ul>
  

</nav>
					<?php 
							if(isset($_SESSION['success'])) : ?>
					
									<div>
										<h3>
										<?php 
											echo $_SESSION['success'];
											unset($_SESSION['success']);

										?>
										</h3>
									</div>
							<?php endif ?>
							
							
	<div class="container-fluid " >
		<h2 style="text-align: center; color: black;">General menu items</h2>
		
	</div>
	<div class="container-fluid menu-header">
		<div class="container menu-container" >
			
				<?php while($rows=mysqli_fetch_assoc($fetch_result))
							    	{
							    	?>
							 <div class="container">
							    <div class="container" style="background-color: #567398; width: 450px;">
					<hr style="height:2px;border-width:0;color:gray;background-color:gray; width: 40%;">
					
						<div class="" style="margin-right: 0px;">
							<?php echo '<img src="data:image;base64,'.base64_encode($rows['image']).'" alt="image"  style="width:410px;height:280px;">'; ?>
						</div>
					
						<div class="">
							<h2><?php echo $rows['drinkName']; ?></h2>
							<p style="color: green;"><b><?php echo $rows['flavour']; ?></b></p>
							<p><b>Price: <?php echo $rows['price']; ?></b></p>
						</div>
						
						<div class="">
							<a href="menu.php"><button class="btn btn-outline-dark" style="margin: 10px;">Order this</button></a>
							
						</div>
								</div>
							    	</div>
				
				
				<?php } ?>
			
			</div>
		

		
				
	
	</div>



</body>
</html>