
<?php
include_once 'server.php';
if(count($_POST)>0) {
mysqli_query($db,"UPDATE drinkitem set id='" . $_POST['id'] . "', flavour='" . $_POST['flavour'] . "', description='" . $_POST['description'] . "', price='" . $_POST['price'] . "' WHERE id='" . $_POST['id'] . "'");
$message = "Record Modified Successfully";
header("Location: admin.php");
echo $message;
}

$result = mysqli_query($db,"SELECT * FROM drinkitem WHERE id='" . $_GET['id'] . "'");
$row= mysqli_fetch_array($result);

?>
<html>
<head>
<title>Update Pizza Data</title>
<link rel="stylesheet" type="text/css" href="resources/style.css">
	<link rel="stylesheet" href="resources/bootstrap-4/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

	<div class="container adminForm-p" >
			<div class="row">
				<div class="col-4"></div>
				<div class="col-4 adminForm-c">
					<h2 style="color: aliceblue">Edit items</h2>
					<form name="frmUser" method="post" action="">
						<input type="hidden" name="id" class="txtField" value="<?php echo $row['id']; ?>">
						<div class="form-group">
							<label for="name" style="color: aliceblue">Pizza Name:</label>
							<input type="text" name="flavour" class="txtField form-control" value="<?php echo $row['flavour']; ?>">
						    
						</div>
						<div class="form-group">
							<label for="pizzaName" style="color: aliceblue">Pizza Description:</label>
							
							<input type="text" name="description" class="txtField form-control" value="<?php echo $row['description']; ?>">

						</div>
						<div class="form-group">
							<label for="price" style="color: aliceblue">Price:</label>
							<input type="number" name="price" class="txtField form-control" value="<?php echo $row['price']; ?>">
							
						</div>
						
						<div class="form-group">
							<div class="row">
								<input type="submit" name="submit" value="Submit" class="buttom">
								<div class="col"><button class="btn btn-primary"><a href="genMenu.php" style="color: black">Go to Menu</a></button></div>
							</div>
							
						</div>
						
					</form>
				</div>
				<div class="col-4"></div>
			</div>
				</div>

</body>
</html>