<?php

session_start();
//initialize variables
$username = "";
$email = "";
$errors = array();

//connect to the db
$db = mysqli_connect('localhost', 'root', '', 'drink_database') or die("could not connect to database");

	
if (isset($_POST['customer_register'])) {
	// receive all input values from the form
$name 	= mysqli_real_escape_string($db, $_POST['name']);
$email    	= mysqli_real_escape_string($db, $_POST['email']);
$contact    	= mysqli_real_escape_string($db, $_POST['contact']);
$password = mysqli_real_escape_string($db, $_POST['pswd']);

$query = "INSERT INTO customer (name, email, contact, password) VALUES ('$name', '$email', '$contact', '$password')";
	mysqli_query($db, $query);
	
	header('Location: customer_login.php');

}


//login customer
if (isset($_POST['login_user'])) {
	$name = mysqli_real_escape_string($db, $_POST['name']);
	$password = mysqli_real_escape_string($db, $_POST['password']);

	
	if (count($errors) == 0) {
		

		$query = "SELECT * FROM customer WHERE name = '$name' AND password = '$password' ";
		$result = mysqli_query($db, $query);
		if (mysqli_num_rows($result)) {
			$_SESSION['name'] = $name;
			$_SESSION['success'] = "Logged in successfully";
			header('Location: menu.php');
		}else{
			
			$_SESSION['message'] = "You have entered wrong credentials. Please try again!";
			header('Location: errors.php');
		}
	}
}

//register admin
if (isset($_POST['admin_register'])) {
	// receive all input values from the form
$name 	= mysqli_real_escape_string($db, $_POST['adminusername']);
$email    	= mysqli_real_escape_string($db, $_POST['adminemail']);
$password = mysqli_real_escape_string($db, $_POST['adminpassword']);

$runquery = "INSERT INTO admin (admin_username, admin_email, admin_password) VALUES ('$name', '$email', '$password')";
	mysqli_query($db, $runquery);
	
	header('Location: adminLogin.php');

}

//login admin
if (isset($_POST['login_admin'])) {
	$username = mysqli_real_escape_string($db, $_POST['adminusername']);
	$password = mysqli_real_escape_string($db, $_POST['adminpassword']);

	

	if (count($errors) == 0) {
		

		$query = "SELECT * FROM admin WHERE admin_username = '$username' AND admin_password = '$password' ";
		$results = mysqli_query($db, $query);

		if (mysqli_num_rows($results)) {
			$_SESSION['admin_username'] = $username;
			$_SESSION['success'] = "Logged in successfully";
			header('Location: admin.php');
		}else{
			$_SESSION['message'] = "You have entered wrong credentials. Please try again!";
			header('Location: errors.php');
		}
	}
}


//register customer

	


// fetch customer data 

	$query = "SELECT * FROM customer";
	$resultSQL = mysqli_query($db, $query);	

//add items from admin panel
if (isset($_POST['addDrink'])) {

$flavourName = 	$_POST['flavourName'];
$drinkName = 	$_POST['drinkName'];
$size 		 = 	$_POST['size'];
$description = 	$_POST['description'];
$price 		 = 	$_POST['price'];
$imagetmp = addslashes(file_get_contents($_FILES['myphoto']['tmp_name']));

/*$file = addslashes(file_get_contents($_FILES['photo']['tmp_name']));*/

$query = "INSERT INTO drinkitem (flavour, drinkName, quantity, description, price, image) VALUES ('$flavourName', '$drinkName', '$size', '$description', '$price', '$imagetmp')";

$queryRun = mysqli_query($db, $query);

header('Location: admin.php');


}

//fetch drink from database
	$query = "SELECT * FROM drinkitem";
	$fetch_result = mysqli_query($db, $query);	




?>
