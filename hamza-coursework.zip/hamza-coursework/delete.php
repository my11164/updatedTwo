<?php
include_once 'server.php';
$id= $_GET ['id'];
$sql = "DELETE FROM drinkitem WHERE id= '$id'";
if (mysqli_query($db, $sql)) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . mysqli_error($db);
}
mysqli_close($db);
header('Location: admin.php');



?>