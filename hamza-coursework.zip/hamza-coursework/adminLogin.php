<?php 

include('server.php');


 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin Login</title>
	<link rel="stylesheet" type="text/css" href="resources/style.css">
	<link rel="stylesheet" href="resources/bootstrap-4/css/bootstrap.min.css">
</head>
<body style="background-color: aliceblue;">
	<header class="backgroundLoginPage">
		
	<div class="container" style="background-color: #56739894;">
		<div class="container1">
			<h3 class="h3-1" style="color: aliceblue;">Admin login</h3>
			<div class="row">
				<div class="col-sm-3"></div>
				<div class="col-sm-5 ">
					<div class="container">
  
				 <form action="server.php" method="post">
				    <div class="form-group">
				      <label for="name" style="color: aliceblue;">Username:</label>
				      <input type="text" class="form-control" name="adminusername" required="">
				    </div>
				   
				     <div class="form-group">
				      <label for="password" style="color: aliceblue;">Password:</label>
				      <input type="password" class="form-control" name="adminpassword" required="">
				    </div>
				    
				    
				    <button type="" class="btn btn-primary" name="login_admin" style="background-color: #80808078;">Login</button>
				   <a href="registerAdmin.php" style="color: aliceblue">Not have an account? <b>Registere Here</b></a> 
				   
				    
				 </form>
				 <a href="index.php"><button type="" class="btn" style="margin-top: 2px; background-color: #80808078; color: #f0f8ff;">Back to Home</button></a>
				</div>
				</div>
			</div>
			
		</div>
	</div>

</body>
</html>