<!DOCTYPE html>
<html>
<head>
	<title>Drink Is Online</title>
	<link rel="stylesheet" type="text/css" href="resources/style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="resources/style.css">
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>

	

	<header class="">
		<nav class="navbar navbar-expand-sm  justify-content-center nav1">
<a class="navbar-brand navbrand" href="index.php">
  <img src="resources/images/mainLogo.png" alt="website logo" height="90px;" width="">
</a>
  <!-- Links -->

  <ul class="navbar-nav ">
    <li class="nav-item navitem">
      <a class="nav-link nav_a" href="#">Home</a>
    </li>
	 <li class="nav-item navitem">
      <a class="nav-link nav_a" href="genMenu.php">Menu</a>
    </li>
    <li class="nav-item navitem">
      <a class="nav-link nav_a" href="#">Contact Us</a>
    </li>
    <li class="nav-item navitem">
      <a class="nav-link nav_a" href="#">Place an Order</a>
    </li>
  </ul>
  <ul class="nav navbar-nav navbar-right">
      <li class="nav-item navitem"><a href="form.php"><button class="btn btn1">Sign Up</button></a></li>
      <li class="nav-item navitem"><a href="customer_login.php"><button class="btn btn1">Log In</button></a></li>
    </ul>

</nav>

