<?php include('server.php'); 

if (!isset($_SESSION['name'])) {
	header("Location: customer_login.php");
}
if(isset($_GET['logout']))
{
	session_destroy();
	unset($_SESSION['name']);
	header("Location: customer_login.php");
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Menu</title>
	<link rel="stylesheet" type="text/css" href="resources/style.css">
	<link rel="stylesheet" href="resources/bootstrap-4/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
		<nav class="navbar navbar-expand-sm  justify-content-center nav1">
<a class="navbar-brand navbrand" href="index.php">
  <img src="resources/images/mainLogo.png" alt="website logo" height="90px;" width="">
</a>
  <!-- Links -->

  <ul class="navbar-nav ">
    <li class="nav-item navitem">
      <a class="nav-link nav_a" href="#">Home</a>
    </li>
	 <li class="nav-item navitem">
      <a class="nav-link nav_a" href="genMenu.php">Menu</a>
    </li>
    <li class="nav-item navitem">
      <a class="nav-link nav_a" href="#">Contact Us</a>
    </li>
    <li class="nav-item navitem">
      <a class="nav-link nav_a" href="#">Place an Order</a>
    </li>
  </ul>
  <ul class="nav navbar-nav navbar-right">
    <li class="nav-item navitem">
      <button class="btn btn-light btn-logout"><a href="menu.php?logout='1'">Logout</a></button>
    </li>
   </ul>

</nav>
	
					<?php 
							if(isset($_SESSION['success'])) : ?>
					
									<div>
										<h3>
										<?php 
											echo $_SESSION['success'];
											unset($_SESSION['success']);

										?>
										</h3>
									</div>
							<?php endif ?>
							
							
	<div class="container-fluid " >
		<h2 style="text-align: center; color: black;">Drinks</h2>
		
	</div>
	<div class="container menu-header">
		<?php while($rows=mysqli_fetch_assoc($fetch_result))
							    	{
							    	?>
		<div class="row">
			<div class="col-md-3">
				
			</div>
			
			<div class="col-md-8">
			<?php echo '<img src="data:image;base64,'.base64_encode($rows['image']).'" alt="image"  style="width:410px;height:280px;">'; ?>
				<h2><?php echo $rows['flavour']; ?></h2>
				<p><b>Price: <?php echo $rows['price']; ?></b></p>
				<button class="btn btn-outline-dark" style="margin: 10px;" data-toggle="modal" data-target="#myModal">Add to cart</button>
			</div>
			<div class="col-md-1">
				
			</div>
		
		</div>

		<?php } ?>
		</div>

<!--modal start-->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Order Form</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
	        <div class="modal-body modalstyle">
				 <form>
				 	<h2>Drinks delivered in under 60 minutes</h2>
		        	 <div class="row">

					    <div class="col">
					    	<label for="name">Card holder name:</label>
					      	<input type="text" class="form-control" name="name" required>
					    </div>
					    <div class="col">
					    	<label for="cardNumber">Card Number:</label>
					      	<input type="text" class="form-control" name="cardNumber" required>
					    </div>
					</div>
				  <div class="form-group">
						    <label for="address">Address:</label>
						    <input type="text" class="form-control" id="address" required>
				  </div>
				  <div class="form-group">
						    <label for="address">Zip Code:</label>
						    <input type="text" class="form-control" id="zCode" required>
				  </div>
					  
		  			<button type="submit" class="btn btn-primary" >Place order</button>
			</form>
	        </div>
        
		        <!-- Modal footer -->
		        <div class="modal-footer">
		        	<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
		        </div>
        
      </div>
    </div>
  </div>
<!--modal end-->



</body>
</html>