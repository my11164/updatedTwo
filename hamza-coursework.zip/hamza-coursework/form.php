<?php include('server.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>User Registeration</title>
	<link rel="stylesheet" type="text/css" href="resources/style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body style="background-color: aliceblue;">
	<header class="headera1">
		<nav class="navbar navbar-expand-sm  justify-content-center nav1">
<a class="navbar-brand navbrand" href="index.php">
	<img src="resources/images/mainLogo.png" alt="website logo" height="50px;" width="">
</a>
  <!-- Links -->

  <ul class="navbar-nav ">
    <li class="nav-item navitem">
      <a class="nav-link nav_a" href="index.php">Home</a>
    </li>
	 <li class="nav-item navitem">
      <a class="nav-link nav_a" href="#">Menu</a>
    </li>
    <li class="nav-item navitem">
      <a class="nav-link nav_a" href="#">About</a>
    </li>
  </ul>
  <ul class="nav navbar-nav navbar-right">
      
      <li class="nav-item navitem"><a href="customer_login.php"><button class="btn btn1">Log In</button></a></li>
    </ul>

</nav>
	<div class="container" style="margin-top: 20px;">
		<div class="container1">
			<h3 class="h3-1">Registeration Form</h3>
			<div class="row">
				<div class="col-sm-3"></div>
				<div class="col-sm-5 form-a">
					<div class="container">
  
				 <form action="server.php" method="post">
				    <div class="form-group">
				      <label for="name">Full Name: <span style="color: red;">&#42;</span></label>
				      <input type="text" class="form-control"  placeholder="Enter your Name" name="name" required="">
				    </div>
				     <div class="form-group">
				      <label for="email">Email: <span style="color: red;">&#42;</span></label>
				      <input type="email" class="form-control"  placeholder="Enter email" name="email" required="">
				    </div>
				     <div class="form-group">
				      <label for="phone">Phone #: <span style="color: red;">&#42;</span></label>
				     
				      <input type="tel" id="phone" class="form-control"  placeholder="123-45-678" pattern="[0-9]{3}-[0-9]{2}-[0-9]{3}" name="contact" required="">
				    </div>
				    <div class="form-group">
				      <label for="pwd">Password: <span style="color: red;">&#42;</span></label>
				      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pswd" required="">
				    </div>
				    <div class="form-group form-check">
				      <label class="form-check-label">
				        <input class="form-check-input" type="checkbox" name="remember">Remember Me
				      </label>
				    </div>
				    <button type="submit" class="btn btn1" name="customer_register">Enter to Submit</button>

				 </form>
				 
				</div>
				</div>
			</div>
			
		</div>
	</div>

</body>
</html>