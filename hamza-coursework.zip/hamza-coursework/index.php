<?php include_once 'header.php';?>

<div class="container-fluid" style="">
  <div class="row midsec">
    <div class="col-md-8 header-1">
     
    </div>
    <div class="col-md-4 headerx">
      <div class="text-center btn_order">
         <div class="container ">
          <h2 class="ha1">Let the drinks come to you.</h2>
          <h3 class="ha2">Drinks on tap.</h3>
      </div>
          <a href="genMenu.php"><button type="button" class="btn btn1 " style="margin: 30px;">Get It</button></a> 
     </div>
    </div>
  </div>
</div>
	


	 
	<div class="wrapper">
            
                  <h4>Follow for updates</h4>
                <a href="http://www.google.com"><i class="fa fa-google-plus"></i></a>
                <a href="http://www.facebook.com"><i class="fa fa-facebook-square"></i></a>
                <a href="#"><i class="fa fa-linkedin-square"></i></a>
                <a href="#"><i class="fa fa-tumblr-square"></i></a>
              </div>
</div>
              
	</header>

  

