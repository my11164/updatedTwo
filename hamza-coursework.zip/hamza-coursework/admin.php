<?php 
include('server.php');

if (!isset($_SESSION['admin_username'])) {
	header("Location: adminLogin.php");
}


if(isset($_GET['logout']))
{
	session_destroy();
	unset($_SESSION['adminusername']);
	header("Location: adminLogin.php");
}

?>

<!-- <?php 
	if (isset($_GET['edit'])) {
		$id = $_GET['edit'];
		$update = true;
		$record = mysqli_query($db, "SELECT * FROM info WHERE id=$id");

		if (count($record) == 1 ) {
			$n = mysqli_fetch_array($record);
			$name = $n['name'];
			$description = $n['description'];
			$price = $n['price'];
		}
	}
?> -->

<!DOCTYPE html>
<html>
<head>
	<title>Admin Page</title>
	<link rel="stylesheet" type="text/css" href="resources/style.css">
	<link rel="stylesheet" href="resources/bootstrap-4/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body class="adminbody">

		<div class="container-fluid admin-div1" >
			<div class="container">
				<div class="row">
					<div class="col-2"></div>
					<div class="col-6"><h2 ><?php 
							if(isset($_SESSION['success'])) : ?>
					
									<div>
										<h3>
										<?php 
											echo $_SESSION['success'];
											unset($_SESSION['success']);

										?>
										</h3>
									</div>
							<?php endif ?>

							<?php if(isset($_SESSION['adminusername'])) : ?>
								<h3>Login Successfully to Admin Dashboard<p style="color: green";><strong><?php echo $_SESSION['adminusername'];?></strong></p></h3>





							<?php endif ?></div>
						<div class="col-2" style="margin: 12px;">
						<button class="btn btn1 btn-logout" style="background-color: #d5a85a;"><a href="admin.php?logout='1'">Logout</a></button>
					</div>
				</div>

			</div>

		<div class="container" >
			<div class="row">
				<div class="col-md-6 col-sm-12">
					<img src="resources/images/adminsec.jpg" alt="" width="100%" height="500" style="margin-top: 28px;">

				</div>
				<div class="col-md-6">
					<h2 style="color: aliceblue">Add new drink</h2>
					<form action="server.php" method="POST" enctype="multipart/form-data">
						<div class="form-group">
							<label for="drinktype" style="color: aliceblue">Category:</label>
								<select id="drinktype" name="flavourName" class="form-control">
								  <option value="Alcohlic">Alcohlic</option>
								  <option value="Non Alcohlic">Non Alcohlic</option>
								 
								</select>

						</div>
						<div class="form-group">
							<label for="drinkName"  style="color: aliceblue">Drink Name:</label>
								<input type="text" name="drinkName" class="form-control">

						</div>
						<div class="form-group">
							<label for="drinksize" style="color: aliceblue">Size:</label>
								<select id="drinksize" name="size" class="form-control">
									  <option value="fiveml">5 ml</option>
									  <option value="onelitre">1 Litre</option>
									  <option value="onehalf">1.5 Litre</option>
									  <option value="twolitre">2 Litre</option>
								</select>

						</div>
						<div class="form-group">
							<label for="pizzaName" style="color: aliceblue">Description:</label>
							<textarea class="form-control" rows="5" name="description" required></textarea>

						</div>
						
						
						<div class="form-group">
							<label for="price" style="color: aliceblue">Price:</label>
							<input type="number" class="form-control" name="price" required>
						</div>

						<div class="form-group">
							<label for="photo" style="color: aliceblue">Image:</label>
						   	<input type="file" class="form-control" name="myphoto" required="Image is required">
						</div>

						<div class="form-group">
							<div class="row">
								<div class="col"><button type="submit" name="addDrink" class="btn " style="background-color: #d5a85a;">Submit</button></div>
								<div class="col"><button class="btn" style="background-color: #d5a85a;"><a href="menu.php" style="color: black">Go to Menu</a></button></div>
							</div>
							
						</div>
						
					</form>
				</div>
						  
			

					
				</div>
				<div class="row">
					<h2 style="color: aliceblue">Drinks</h2>
						  <p style="color: aliceblue">Add/edit drinks:</p>            
							  <table class="table table-bordered">
							    <thead>
							      <tr>
							      	<th>ID</th>
							        <th>Category</th>
							        <th>Drink Name</th>
							        <th>Discription</th>
							        <th>Price</th>
							        <th>Actions</th>
							      </tr>
							    </thead>
							    <tbody>
							     
										<?php
										$i=0;
										while($row = mysqli_fetch_array($fetch_result)) {
										?>
										<tr>
										<td><?php echo $row["id"]; ?></td>
										<td><?php echo $row["flavour"]; ?></td>
										<td><?php echo $row["drinkName"]; ?></td>
										<td><?php echo $row["description"]; ?></td>
										<td><?php echo $row["price"]; ?></td>
										
										
										<td><a href="updateItem.php?id=<?php echo $row['id']; ?>">
											<button class="btn" style="background-color: #d5a85a;">Edit</button></a>
											<a href="delete.php?id=<?php echo $row['id']; ?>" class="anchor-2"><button class="btn " style="background-color: #d5a85a;">Delete</button></a>
										</td>
										</tr>
										<?php
										$i++;
										}
										?>
							    </tbody>
							  </table>
					</div>
										<!--customer record section -->
					<div class="row">
						<h2 style="color: aliceblue">Customer record</h2>
						  <p style="color: aliceblue">Add/edit Customer data:</p>            
							  <table class="table table-bordered">
							    <thead>
							      <tr>
							      	<th>ID</th>
							        <th>Customer Name</th>
							        <th>Email</th>
							        <th>Contact</th>
							      	<th>Actions</th>
							      </tr>
							    </thead>
							    <tbody>
							     
										<?php
										$i=0;
										while($rows = mysqli_fetch_array($resultSQL)) {
										?>
										<tr>
										<td><?php echo $rows["id"]; ?></td>
										<td><?php echo $rows["name"]; ?></td>
										<td><?php echo $rows["email"]; ?></td>
										<td><?php echo $rows["contact"]; ?></td>
										<td><a href="userUpdate.php?id=<?php echo $rows['id']; ?>">
											<button class="btn btn-sm" style="background-color: #d5a85a;">Edit</button></a>
											<a href="userDelete.php?id=<?php echo $rows['id']; ?>" class="anchor-2"><button class="btn btn1 btn-sm" style="background-color: #d5a85a;">Delete</button></a>
										</td>
										</tr>
										<?php
										$i++;
										}
										?>
							    </tbody> 
							  </table>
					</div>
				</div>
			</div>

			
			
				
			<!-- end of customer record section -->

		</div>	

		</div>
	
		

</body>
</html>