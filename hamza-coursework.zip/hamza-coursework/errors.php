<?php 
session_start();
?>


<!DOCTYPE html>
<html>
<head>
	<title>Error</title>
	<link rel="stylesheet" type="text/css" href="resources/style.css">
	<link rel="stylesheet" href="resources/bootstrap-4/css/bootstrap.min.css">
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col"></div>
			<div class="col" style="background-color: red; height: 300px;">
				
					 
					    	<h1 style="color: aliceblue;">Sorry!</h1>
					    	<p style="color: aliceblue;">
					    		<?php 
									if (isset($_SESSION['message'])) : 

									echo $_SESSION['message'];
									else:
									header("location: admin.php");
									endif

								?>
					    	</p>
					    	<br>
					<a href="index.php"><button class="btn btn-block btn-outline-info">Back</button></a>
			</div>
			<div class="col"></div>
		</div>
	</div>
</body>
</html>

