
<?php
include_once 'server.php';
if(count($_POST)>0) {
mysqli_query($db,"UPDATE customer set id='" . $_POST['id'] . "', name='" . $_POST['name'] . "', email='" . $_POST['email'] . "', contact='" . $_POST['contact'] . "' WHERE id='" . $_POST['id'] . "'");
$message = "Record Modified Successfully";
header("Location: admin.php");
}

$result = mysqli_query($db,"SELECT * FROM customer WHERE id='" . $_GET['id'] . "'");
$row= mysqli_fetch_array($result);

?>
<html>
<head>
<title>Update Pizza Data</title>
<link rel="stylesheet" type="text/css" href="resources/style.css">
	<link rel="stylesheet" href="resources/bootstrap-4/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

	<div class="container adminForm-p" >
			<div class="row">
				<div class="col-4"></div>
				<div class="col-4 adminForm-c">
					<h2 style="color: aliceblue">Edit items</h2>
					<form name="frmUser" method="post" action="">
						<input type="hidden" name="id" class="txtField" value="<?php echo $row['id']; ?>">
						<div class="form-group">
							<label for="name" style="color: aliceblue">Name:</label>
							<input type="text" name="name" class="txtField form-control" value="<?php echo $row['name']; ?>">
						    
						</div>
						<div class="form-group">
							<label for="email" style="color: aliceblue">Customer Email:</label>
							
							<input type="text" name="email" class="txtField form-control" value="<?php echo $row['email']; ?>">

						</div>
						<div class="form-group">
							<label for="contact" style="color: aliceblue">Customer contact:</label>
							<input type="" name="contact" class="txtField form-control" value="<?php echo $row['contact']; ?>">
							
						</div>
						
						<div class="form-group">
							<div class="row">
								<input type="submit" name="submit" value="Submit" class="buttom">
								
							</div>
							
						</div>
						
					</form>
				</div>
				<div class="col-4"></div>
			</div>
				</div>

</body>
</html>